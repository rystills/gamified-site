/**
 * Player class: describes the playable charaacter
 * @param x: the starting x coordinate
 * @param y: the starting y coordinate
 * @param type: the tile type for this instance
 */

tileTypes = new Enum("grassTop","grassLeft","grassRight","dirt","water","lava");
tleStates = new Enum("solid","liquid","lava","intangible");
tileProperties = {};
tileProperties[tileTypes.grassTop] = {imgName:"ground.png",state:tileStates.solid};

makeChild("Tile","GameObject");
function Tile(x,y,type) {
    this.type = type;
    RygameObject.call(this,x,y,tileProperties[tileTypes.grassTop].imgName);
}