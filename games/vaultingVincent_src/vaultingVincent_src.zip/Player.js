/**
 * Player class: describes the playable charaacter
 * @param x: the starting x coordinate
 * @param y: the starting y coordinate
 */
Player.prototype.update = function() {
    if (keys["A"]) {
        x -= 2;
    }
    if (keys["D"]) {
        x += 2;
    }
}

makeChild("Player","GameObject");
function Player(x,y) {
    RygameObject.call(this,x,y,"player");
}